import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
public class firstPage extends JFrame {

    private JLabel game_lab = new JLabel();
    private JFrame frame = new JFrame();
    public boolean guest = false;

    public firstPage() {
        JButton login_btn = new JButton("Login");
        JButton guest_btn = new JButton("Continue as Guest");
        frame.setSize(800, 800);
        frame.setResizable(false);
        frame.setLayout(null);
        frame.setTitle("Chess Game");
        frame.getContentPane().setBackground(new Color(0x494949));
        login_btn.setBounds(300, 375, 200, 40);
        guest_btn.setBounds(300, 435, 200, 40);
        game_lab.setForeground(Color.white);
        game_lab.setBounds(250, 200, 400, 100);
        game_lab.setFont(new Font("B", Font.BOLD, 48));
        login_btn.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                System.out.println("Open Login Page !!");
                login_page log = new login_page();
                dispose(); //close it to open login page
            }
        });
        guest_btn.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                System.out.println("Open New Game Page!!");
                guest = true; //to know that he is a guest
                new_game gam = new new_game(guest);      //guest
                dispose();                  //close it to open guest page
            }
        });
        frame.add(login_btn);
        frame.add(guest_btn);
        frame.add(game_lab);
        frame.setVisible(true);

    }


}
