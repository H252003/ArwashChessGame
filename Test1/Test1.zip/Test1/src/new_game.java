import javax.swing.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class new_game extends JFrame {
    public static boolean isNotNumeric(String strNum) {
        if (strNum == null) {
            return true;
        }
        try {
            int d = Integer.parseInt(strNum);
        } catch (NumberFormatException nfe) {
            return true;
        }
        return false;
    }
    private JLabel white_lab = new JLabel();
    private JPanel MainPanel = new JPanel();
    private JTextField white_name = new JTextField();
    private JLabel black_lab =new JLabel();
    private JTextField black_name =new JTextField();
    private JLabel timer_lab=new JLabel();
    private JTextField timer_value=new JTextField();
    private JButton start_btn=new JButton("Start");
    private JButton back_btn=new JButton("Back");

    public new_game(boolean if_guest)
    {
        setTitle("ahleeen");
        setContentPane(MainPanel);
        MainPanel.add(start_btn);
        MainPanel.add(back_btn);
        MainPanel.add(white_name);
        MainPanel.add(black_name);
        MainPanel.add(timer_value);
        setDefaultCloseOperation(EXIT_ON_CLOSE);
        setSize(700,400);
        setVisible(true);

        start_btn.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                String timer = timer_value.getText();
                System.out.println("White player is: " + white_name.getText());
                System.out.println("Black player is: " + black_name.getText());
                System.out.println("Time allowed is: " + timer);


                if(isNotNumeric(timer))         // check if timer is numbers only
                {
                    System.out.println("input correct timer");
                    JOptionPane.showMessageDialog(null, "input correct timer");

                }
                else {
                    game Game = new game();
                }
            }
        });
        back_btn.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                System.out.println("GOOOOO back to new game or retrieve game (if logged in)");

                if(if_guest)        //GOOO back to login or guest page if its a guest
                {
                    firstPage guest_ = new firstPage();
                    guest_.show();   //show the first page
                    dispose();   //close new game page
                }
                else{        //this is a user
                    System.out.println("this is a user !!!!!");

                  /* loggedin_page user = new loggedin_page();
                   user.show();   //show the first page
                   dispose();   //close new game page

                   */
                }
            }
        });
    }


    public static void main(String args[])
    {
        // new new_game();
    }
}
