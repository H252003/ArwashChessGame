import javax.swing.*;
import javax.swing.JFrame ;
import javax.swing.event.AncestorListener;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.lang.*;
public class Main_jr extends JFrame implements ActionListener {
    JButton button1 = new JButton("Start");
    JButton button2 = new JButton("Status");
    JButton button3 = new JButton("Logout");
    JFrame frame = new JFrame();
    JLabel label = new JLabel();

    Main_jr() {
        frame.setSize(800, 800);
        frame.setResizable(false);
        frame.setLayout(null);
        frame.setTitle("Chess Game");
        frame.getContentPane().setBackground(new Color(0x494949));
        ImageIcon image = new ImageIcon("th.jpeg");
        frame.setIconImage(image.getImage());
        button1.setBounds(300, 375, 200, 40);
        button2.setBounds(300, 435, 200, 40);
        button3.setBounds(10, 700, 100, 40);
        label.setText("Main Page");
        label.setForeground(Color.white);
        label.setBounds(250, 200, 400, 100);
        label.setFont(new Font("B", Font.BOLD, 48));
        button1.addActionListener(this);
        button2.addActionListener(this);
        button3.addActionListener(this);
        frame.add(button1);
        frame.add(button2);
        frame.add(button3);
        frame.add(label);
        frame.setVisible(true);
    }
    @Override
    public void actionPerformed(ActionEvent e) {
        if(e.getSource()==button1){
            new_game Game = new new_game(false);
        }
        if(e.getSource()==button2){
            Status status= new Status();
        }
        if(e.getSource()==button3){
            JOptionPane.showConfirmDialog(null,"Do you want to logout ?","Warning",JOptionPane.YES_NO_CANCEL_OPTION);


        }
    }
}