import javax.swing.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class login_page extends JFrame {
    private JPanel panel1;
    private JButton BACKButton;
    private JButton LOGINButton;
    private JTextField username;
    private JPasswordField password;

    public login_page() {
        panel1 = new JPanel();
        BACKButton = new JButton("Back");
        LOGINButton = new JButton("Login");
        username = new JTextField();
        password = new JPasswordField();
        setTitle("loggggg");
        setContentPane(panel1);
        setDefaultCloseOperation(EXIT_ON_CLOSE);
        setSize(600, 400);
        setVisible(true);
        panel1.add(BACKButton);
panel1.add(LOGINButton);
panel1.add(username);
panel1.add(password);

        BACKButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                firstPage f = new firstPage();
                dispose();

            }
        });
        LOGINButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                String user = username.getText();
                String pass = password.getText();
                if (user.equals("admin")) {
                    JOptionPane.showMessageDialog(null, "helloooo!");
                    System.out.println("logged in page!!");
                    new Main_jr();
                }
            }
        });
    }}